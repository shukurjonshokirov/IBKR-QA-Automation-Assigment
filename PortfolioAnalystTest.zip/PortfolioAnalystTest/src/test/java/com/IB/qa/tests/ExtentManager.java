package com.IB.qa.tests;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentManager {
	 private static ExtentReports extent;

	    public static ExtentReports getReportInstance() {
	        if (extent == null) {
	            ExtentSparkReporter reporter = new ExtentSparkReporter("test-output/ExtentReport.html");
	            
	            reporter.config().setTheme(Theme.STANDARD);
	            reporter.config().setReportName("IBKR QA Automation Report");
	            reporter.config().setDocumentTitle("Test Report");
	            
	            
	            extent = new ExtentReports();
	            extent.attachReporter(reporter);
	            
	        }
	        return extent;
	    }
}
