package com.IB.qa.tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

public class BaseTest {
	 protected WebDriver driver;
	    protected ExtentReports extent;
	    protected ExtentTest test;

	    @BeforeClass
	    public void setUp() {
	        extent = ExtentManager.getReportInstance();
	        driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.get("https://ndcdyn.interactivebrokers.com/sso/Login?RL=1&locale=en_US");
	    }

		
		  @AfterClass public void tearDown() { if (driver != null) { driver.quit(); }
		  extent.flush(); }
		 
} 
	 
	
	

