package com.IB.qa.tests;

import java.time.Duration;
import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class LoginTestAndTest1 extends BaseTest{
	SoftAssert softAssert = new SoftAssert();
	 @Test
	    public void loginToPortfolioAnalyst() throws InterruptedException {
	       
	        WebElement username = driver.findElement(By.name("username"));
	        username.sendKeys("testah000");

	       
	        WebElement password = driver.findElement(By.name("password"));
	        password.sendKeys("tester12");

	        
	        WebElement loginBtn = driver.findElement(By.xpath("//button[contains(@class,'btn btn-lg btn-primary')]"));
	        loginBtn.click();
	       
	        //-----------------------------------------------------------------------------------------------------------
	        try {
	        	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	        	WebElement continueLink = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class = 'ibkey-promo-skip']")));
	        	continueLink.click();
	        	System.out.println("Success!");
				
			} catch (TimeoutException e) {
				System.out.println("Continue link not found - maybe because of QR");
			}
			// validate that PortfolioAnalist page has loaded
	        
	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
	        WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@type= 'text']")));
	        Thread.sleep(3000);
	        String currentUrl = driver.getCurrentUrl();
	        
	        //softAssert.assertTrue(currentUrl.contains("https://ndcdyn.interactivebrokers.com/sso/Dispatcher"), "Login failed or incorrect page loaded.");
	       // softAssert.assertAll();
	    }
	 @Test(dependsOnMethods = "loginToPortfolioAnalyst")
	 public void validateCostcoCardUnderOtherSection() throws InterruptedException {
	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

	        // 1. Enter "Citibank" in the search input
	        WebElement searchInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@type= 'text']")));
	        searchInput.clear();
	        System.out.println("search line active");
	        searchInput.click();
	        searchInput.sendKeys("Citibank");
	        System.out.println("Inserted text in the search line");
	        Thread.sleep(3000); // Allow results to populate

	        // 2. Validate it appears under the "Other" section
	        WebElement costcoUnderOther = driver.findElement(By.xpath("//a[contains(@class,'btn btn-default')]"));
	        Assert.assertTrue(costcoUnderOther.isDisplayed(), "Costco Wholesale Credit Card NOT found under Other section!");

	        // 3. Validate it does NOT appear under the "Best Match" section
	        List<WebElement> costcoUnderBestMatch = driver.findElements(By.xpath("//div[@class='btn-selectors']"));
	        
       boolean costcoFound = false;
       
       for (WebElement item  : costcoUnderBestMatch) {
			String name = item.getText().trim();
			if (name.equalsIgnoreCase("Costco Wholesale Credit Card")) {
				costcoFound = true;
				break;
				
			}
		}
     Assert.assertFalse(costcoFound, "Costco Wholesale Credit Card incorrectly appears under Best Match!");
	        // 4. Click the 'X' to close modal
	        WebElement closeBtn = driver.findElement(By.xpath("//div[@class = 'input-group-append']/span"));
	        closeBtn.click();
	    }
	
}
