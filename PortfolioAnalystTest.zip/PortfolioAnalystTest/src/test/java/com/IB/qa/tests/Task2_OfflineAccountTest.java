package com.IB.qa.tests;

import java.lang.reflect.Method;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.*;
import com.aventstack.extentreports.Status;

public class Task2_OfflineAccountTest extends LoginTestAndTest1 {

    WebDriverWait wait;
    SoftAssert softAssert = new SoftAssert();
    ExtentReports extent;
    ExtentTest test;

    @BeforeSuite
    public void setupReport() {
        extent = ExtentManager.getReportInstance(); // Your ExtentManager.java
    }

    @BeforeMethod
    public void createTest(Method method) {
        wait = new WebDriverWait(driver, Duration.ofSeconds(100));
        test = extent.createTest(method.getName());
    }

    @AfterMethod
    public void flushReport() {
        extent.flush();
    }

    @Test(priority = 1)
    public void createBrokerageAccount() throws InterruptedException {
        test.log(Status.INFO, "Starting Brokerage Account creation");
       
        openOfflineAccount();
        fillAccountDetails("Brokerage", "TestBrokerage");
        test.log(Status.INFO, "Filled Brokerage Account details");
        finishAccountCreation(true);
        refreshAndClickConfig();
        test.pass("Brokerage Account created and verified successfully");
    }

    @Test(priority = 2, dependsOnMethods = "createBrokerageAccount")
    public void createCreditCardAccount() throws InterruptedException {
        test.log(Status.INFO, "Starting Credit Card Account creation");
       
        clickPlusButton();
        openOfflineAccount();
        fillAccountDetails("Credit Card", "TestCreditCard");
        test.log(Status.INFO, "Filled Credit Card Account details");
        finishAccountCreation(true);
        test.pass("Credit Card Account created successfully");
    }

    @Test(priority = 3, dependsOnMethods = "createCreditCardAccount")
    public void createRealEstateAccount() throws InterruptedException {
        test.log(Status.INFO, "Starting Real Estate Account creation");
        
        clickPlusButton();
        openOfflineAccount();
        fillAccountDetails("Real Estate", "TestRealEstate");
        finishAccountCreation(false);
        test.pass("Real Estate Account created successfully");
   
    }

    @Test(priority = 4, dependsOnMethods = "createRealEstateAccount")
    public void createOtherAssetAccount() throws InterruptedException {
        test.log(Status.INFO, "Starting Other Asset Account creation");
       
        clickPlusButton();
        openOfflineAccount();
        fillAccountDetails("Other Asset", "TestOtherAsset");
        finishAccountCreation(false);
        test.pass("Other Asset Account created successfully");
    }

    @Test(priority = 5, dependsOnMethods = "createOtherAssetAccount")
    public void createSavingsAccount() throws InterruptedException {
        test.log(Status.INFO, "Starting Savings Account creation");
       
        clickPlusButton();
        openOfflineAccount();
        fillAccountDetails("Savings", "TestSavings");
        finishAccountCreation(true);
        test.pass("Savings Account created successfully");
    }

    private void openOfflineAccount() {
        WebElement offlineBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[contains(@class,'fa fa-university')]")));
        offlineBtn.click();

WebElement continueBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='btn btn-primary white-space-normal'][normalize-space()='Continue']")));
        continueBtn.click();
    }

    private void fillAccountDetails(String type, String title) {
       
    	
    	Select accountTypeSelect = new Select(wait.until(ExpectedConditions.presenceOfElementLocated(By.id("type"))));
        accountTypeSelect.selectByVisibleText(type);

        WebElement titleField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("acctTitle")));
        titleField.sendKeys(title);

        WebElement dateInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='date']")));
        dateInput.click();

       
        
     List<WebElement> validDays = driver.findElements(By.xpath("//td[contains(@class,'day') and not(contains(@class,'disabled')) and not(contains(@class,'old'))]"));
        if (validDays.size() > 3) {
            validDays.get(validDays.size() - 3).click();
     
        } else {
            validDays.get(validDays.size() - 1).click();
        }

      
        
        Select currency = new Select(driver.findElement(By.xpath("//select[contains(@class, 'ng-pristine')]")));
        currency.selectByValue("string:USD");

       
      WebElement balanceField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='balance_0']")));
        balanceField.sendKeys("1000");
    }

    private void finishAccountCreation(boolean hasManualButton) {
        try {
                  Thread.sleep(1000);
       
        } catch (InterruptedException e) {
            test.fail("interrupted: " + e.getMessage());
        }

        if (hasManualButton) {
            WebElement manually = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()='Manually']")));
            manually.click();
        }

        
        
        int totalClicks = hasManualButton ? 3 : 2;
        for (int i = 0; i < totalClicks; i++) {
            WebElement continueBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='panel-btn-right']/p/am-button/a")));
            continueBtn.click();
        }

   WebElement okBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='panel-btn-right']/p/am-button/a")));
        okBtn.click();
    }

    private void refreshAndClickConfig() {
        driver.navigate().refresh();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Configuration']"))).click();
    }

    private void clickPlusButton() throws InterruptedException {
        Thread.sleep(3000);
        
        WebElement plusButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@class='btn-icons']/li[2]/pa-external-account-modal-button/a")));
        plusButton.click();
    }
}