package com.IB.qa.tests;

import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Task2_OfflineAccountTest extends LoginTestAndTest1 {
    WebDriverWait wait;
    SoftAssert softAssert = new SoftAssert();

    @Test(priority = 1)
    public void createBrokerageAccount() throws InterruptedException {
        initializeWait();
        openOfflineAccount();
        fillAccountDetails("Brokerage", "TestBrokerage");
        finishAccountCreation(true);
        refreshAndClickConfig();
    }

    @Test(priority = 2, dependsOnMethods = "createBrokerageAccount")
    public void createCreditCardAccount() throws InterruptedException {
        clickPlusButton();
        openOfflineAccount();
        fillAccountDetails("Credit Card", "TestCreditCard");
        finishAccountCreation(true);
    }

    @Test(priority = 3, dependsOnMethods = "createCreditCardAccount")
    public void createRealEstateAccount() throws InterruptedException {
        clickPlusButton();
        openOfflineAccount();
        fillAccountDetails("Real Estate", "TestRealEstate");
        finishAccountCreation(false);
    }

    @Test(priority = 4, dependsOnMethods = "createRealEstateAccount")
    public void createOtherAssetAccount() throws InterruptedException {
        clickPlusButton();
        openOfflineAccount();
        fillAccountDetails("Other Asset", "TestOtherAsset");
        finishAccountCreation(false);
    }

    @Test(priority = 5, dependsOnMethods = "createOtherAssetAccount")
    public void createSavingsAccount() throws InterruptedException {
        clickPlusButton();
        openOfflineAccount();
        fillAccountDetails("Savings", "TestSavings");
        finishAccountCreation(true);
    }

    private void initializeWait() {
        wait = new WebDriverWait(driver, Duration.ofSeconds(100));
    }

    private void openOfflineAccount() {
        WebElement offlineBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[contains(@class,'fa fa-university')]")));
        offlineBtn.click();

        WebElement continueBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='btn btn-primary white-space-normal'][normalize-space()='Continue']")));
        continueBtn.click();
    }

    private void fillAccountDetails(String type, String title) {
        Select accountTypeSelect = new Select(wait.until(ExpectedConditions.presenceOfElementLocated(By.id("type"))));
        accountTypeSelect.selectByVisibleText(type);

        WebElement titleField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("acctTitle")));
        titleField.sendKeys(title);

        WebElement dateInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='date']")));
        dateInput.click();

        List<WebElement> validDays = driver.findElements(By.xpath("//td[contains(@class,'day') and not(contains(@class,'disabled')) and not(contains(@class,'old'))]"));
       
        if (validDays.size() > 3) {
            validDays.get(validDays.size() - 3).click();
        } else {
            validDays.get(validDays.size() - 1).click();
        }

        
        Select currency = new Select(driver.findElement(By.xpath("//select[contains(@class, 'ng-pristine')]")));
        currency.selectByValue("string:USD");

        WebElement balanceField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='balance_0']")));
        balanceField.sendKeys("1000");
    }

    private void finishAccountCreation(boolean hasManualButton) {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        if (hasManualButton) {
            WebElement manually = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()='Manually']")));
            manually.click();
        }

        int totalClicks = hasManualButton ? 3 : 2;
        for (int i = 0; i < totalClicks; i++) {
            WebElement continueBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='panel-btn-right']/p/am-button/a")));
            continueBtn.click();
        }

        WebElement okBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='panel-btn-right']/p/am-button/a")));
        okBtn.click();
    }

    private void refreshAndClickConfig() {
        driver.navigate().refresh();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Configuration']"))).click();
    }

    private void clickPlusButton() throws InterruptedException {
        Thread.sleep(3000);
        WebElement plusButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@class='btn-icons']/li[2]/pa-external-account-modal-button/a")));
        plusButton.click();
    }
}


